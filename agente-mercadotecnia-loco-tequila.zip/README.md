# Agente Creativo y de Mercadotecnia — Loco Tequila

Skill de dirección creativa y mercadotecnia digital end-to-end para **Loco Tequila**, diseñada para generar campañas publicitarias completas compuestas por **copys nativos listos para publicar** y **prompts ultra detallados** para generadores de Inteligencia Artificial de imagen y video (Midjourney, Flux, DALL-E, Sora, Runway, etc.).

---

## 📌 Tabla de Contenidos

1. [Propósito y Alcance](#-propósito-y-alcance)
2. [Estructura del Proyecto](#-estructura-del-proyecto)
3. [Entorno y Requisitos Técnicos](#-entorno-y-requisitos-técnicos)
4. [Parámetros de Entrada](#-parámetros-de-entrada)
5. [Niveles de Inventiva y Filosofía](#-niveles-de-inventiva-y-filosofía)
6. [Flujo de Trabajo del Agente](#-flujo-de-trabajo-del-agente)
7. [Memoria de Marca y Guardrails Innegociables](#-memoria-de-marca-y-guardrails-innegociables)
8. [Sub-Skills Integradas](#-sub-skills-integradas)
9. [Glosario SEO / GEO y Personas](#-glosario-seo--geo-y-personas)
10. [Pasarela Web Interactiva](#-10-pasarela-web-interactiva-showcase--runway)
11. [Generación de Medios con OpenRouter](#-11-generación-de-medios-con-openrouter-extra-opcional)

---

## 🎯 Propósito y Alcance

### SÍ Hace

- Planear y redactar campañas publicitarias end-to-end para Loco Tequila.
- Detectar automáticamente feriados oficiales y no oficiales de México cruzándolos con fechas clave de la industria de bebidas y temporadas prioritarias de marca.
- Adaptar copys con gramática nativa según la red social de destino (Instagram, Facebook, YouTube, LinkedIn, TikTok).
- Generar prompts ultra detallados para modelos generativos de imagen y video acordes con la estética y paleta de la marca.
- Conectarse mediante Microsoft 365 / OneDrive / SharePoint para auditar piezas anteriores e inspirarse sin repetir diseños.
- Integrar estrategia SEO y optimización para motores generativos (GEO).
- **Ejecutar los prompts** contra los modelos de imagen/video de OpenRouter, como extra posterior a la entrega, si el usuario lo pide y aporta su API Key.

### NO Hace

- Publicar o programar contenido directamente en redes.
- Gestionar pautas publicitarias o presupuestos de medios.
- Generar imágenes o videos **sin autorización explícita del usuario y sin su API Key** (el consumo se cobra a su cuenta de OpenRouter).
- Trabajar con marcas de la competencia (Casa Dragones, Clase Azul, etc.).
- Romper o alterar los hechos históricos y técnicos establecidos de la marca.

---

## 📁 Estructura del Proyecto

```plaintext
agente-mercadotecnia-loco-tequila/
├── SKILL.md                               # Instrucción maestra de la skill
├── README.md                              # Documentación general y técnica
├── AGENTS.md                              # Protocolo operativo (NO se autocarga fuera de este repo; solo apunta a references/)
├── .gitignore                             # Reglas de exclusión de Git
│
├── package_skill.ps1                      # Script PowerShell para empaquetar la skill en ZIP (excluye binarios)
├── package_skill.sh                       # Script Bash para empaquetar la skill en ZIP (excluye binarios)
├── to_do.md                               # Bitácora y registro de tareas realizadas
│
├── designs/                               # Tokens y guías de diseño institucional
│   └── Design.md                          # Sistema de diseño, paleta de color y tokens oficiales
│
├── imagenes/                              # Recursos gráficos institucionales
│   └── Loco_Tequila_Logo_white.png        # Logo oficial en blanco
│
├── references/                            # Fuente de verdad inmutable de la marca
│   ├── brand-context.md                   # Memoria de marca, buyer personas, manifiesto y guardrails
│   ├── fechas-alcohol.md                  # Calendario de fechas de bebidas y prioridades de marca
│   ├── calendario-gastronomico-mexicano.md # Calendario gastronómico mexicano (UNESCO / SIC Gob Ficha 45) y maridaje
│   ├── manual-cumplimiento-ia-2026.md     # Protocolo multicanal IA 2026: 3 niveles, FTC, EU AI Act, 360Brew
│   ├── output-template.md                 # Plantilla estándar de salida de campañas y prompts
│   ├── platforms-process.md               # Matriz por red social y proceso de adaptación
│   ├── curaduria-modelos-imagen.json      # Curaduría propia de generadores por familia (sin Elo ni ranking)
│   ├── productos.md                       # Fichas técnicas del portafolio (Blanco, Ámbar, etc.)
│   ├── prompt-standards.md                # Campos obligatorios de prompts, negatives y prompt ejemplar
│   ├── qa-checklist.md                    # Lista de verificación de calidad antes de entrega
│   ├── seo-geo-glossary.md                # Glosario maestro de keywords y estrategia GEO
│   ├── showcase-rules.md                  # Procedimiento de generación de la Pasarela Web (paso 11)
│   ├── showcase-template.html             # Template de la Pasarela: solo se sustituye su bloque CAMPAIGN
│   ├── loco-tequila/                      # Registros y cánones anatómicos de botellas oficiales
│   │   └── bottle_tequila_offiicial_images/ # Resúmenes de Blanco, Ámbar, Puro Corazón, Áureo y Hierofante
│   └── old_campaigns/                     # Archivo de campañas históricas de Loco Tequila
│       ├── Dia_de_muertos/                # Análisis visual y resumen de alta fidelidad
│       ├── Loco_tequila_ambar/            # Análisis de estilo de vida, mixología y maridaje costero
│       ├── Loco_tequila_blanco/           # Análisis de arquitectura brutalista y pureza radical
│       ├── Loco_tequila_puro_corazon/     # Análisis de artesanos de autor (Adriana Soto) y lujo relajado
│       ├── Mexicanidad/                   # Análisis culinario de Chiles en Nogada y cata sensorial
│       └── resumen_old_campaigns.md       # Memoria visual y directriz de arte transversal
│
├── showcase/                              # Pasarela web interactiva (Showcase / Runway)
│   ├── index.html                         # Vista principal de la pasarela y leaderboard
│   ├── styles.css                         # Estilos basados en Design.md y dark luxury
│   ├── app.js                             # Interactividad, carrusel y copiado
│   ├── assets/                            # Recursos locales (logo oficial)
│   └── data/                              # Datasets JSON de campañas y leaderboard
│
├── outputs/                               # (git-ignored) Medios generados con OpenRouter
│   ├── images/                            # Imágenes generadas — borradores, no piezas aprobadas
│   └── videos/                            # Videos generados
│
└── sub-skill/                             # Sub-habilidades modulares
    ├── generar-medios-openrouter/
    │   ├── README.md                      # Sub-skill que EJECUTA los prompts de la pasarela (paso 12b)
    │   └── generar_medios.py              # Genera imágenes/videos vía OpenRouter desde el HTML de campaña
    ├── obtener-leaderboard-imagen/
    │   ├── README.md                      # Sub-skill del ranking en vivo de generadores (API Design Arena)
    │   └── obtener_leaderboard.py         # Consulta la API y cruza con la curaduría de marca
    ├── leer-imagenes-onedrive/
    │   └── README.md                      # Sub-skill para auditar imágenes previas en OneDrive/SharePoint
    └── obtener-feriados-oficiales-no-oficiales/
        ├── README.md                      # Sub-skill para detección de festivos
        ├── obtener_feriados.py            # Script en Python con scraping y cálculo de feriados
        └── prototipo_feriados.py          # Prototipo exploratorio de scraping y pruebas de feriados
```

---

## ⚙️ Entorno y Requisitos Técnicos

El script de detección de feriados se ejecuta localmente bajo **Anaconda** en el entorno `skills_env`.

### 1. Inicialización de Anaconda en PowerShell

```powershell
& "E:\Users\1167486\AppData\Local\anaconda3\Scripts\conda.exe" shell.powershell hook | Out-String | Invoke-Expression
```

### 2. Activación del Entorno

```powershell
conda activate skills_env
```

### 3. Dependencias del Entorno

Si es necesario instalar o verificar las librerías:

```powershell
pip install holidays requests beautifulsoup4
```

### 4. Ejecución del Script de Feriados

```powershell
python sub-skill/obtener-feriados-oficiales-no-oficiales/obtener_feriados.py --year 2026 --dias 30
```

- `--year AÑO`: Año a consultar (por defecto, el año actual).
- `--dias N`: Filtra únicamente los feriados dentro de los próximos N días (ideal para aviso previo de 30 días).
- `--json ARCHIVO`: Exporta los resultados en formato JSON.

---

## 📥 Parámetros de Entrada

Antes de generar una campaña, la skill solicita o valida los siguientes parámetros:

| Parámetro | Tipo / Opciones | Descripción |
| --- | --- | --- |
| `{{plataformas_destino}}` | Facebook, YouTube, LinkedIn, TikTok, Instagram | Red(es) social(es) destino de la campaña |
| `{{fechas_proximas}}` | Fechas festivas / efemérides | **Obligatorio:** Se detectan a 30 días y se pregunta siempre al usuario cuál desea elegir |
| `{{motivo_gastronomico}}` | `Sí` \| `No` | **Obligatorio si la festividad tiene tradición culinaria:** Pregunta si las imágenes tendrán motivo gastronómico y ofrece listado de platillos de `references/calendario-gastronomico-mexicano.md` |
| `{{producto}}` | Loco Blanco, Loco Ámbar, Loco Puro Corazón, Loco Áureo, Loco Hierofante, Portafolio Completo | Expresión de tequila a promocionar |
| `{{medio}}` | Imagen, Video, Ambas | Define el tipo de prompts generativos a producir |
| `{{referencias_visuales}}` | Link de OneDrive / SharePoint *(Opcional)* | Auditoría de metadatos (pregunta al usuario si desea leer la carpeta para extraer nombres de campañas pasadas, máx. 10, y ofrece adjuntar 1 a 3 imágenes de ejemplo en el chat) |
| `{{numero_ideas}}` | Entero (por defecto `3`) | Cantidad de conceptos a idear por plataforma. **Tope: `redes × numero_ideas` ≤ 6 conceptos**; si se excede, se reduce y se declara en las notas. Evita que la calidad de los prompts se diluya al elegir todas las redes |
| `{{inventiva}}` | `Original` \| `Locura Genial` (por defecto `Original`) | Grado de audacia conceptual |

### Parámetros de los extras (se piden **después** de entregar la pasarela)

| Parámetro | Tipo / Opciones | Descripción |
| --- | --- | --- |
| `{{mostrar_leaderboard}}` | `sí` \| `no` *(por defecto `no`)* | **Opcional.** Ranking en vivo de generadores de IA, para saber con qué herramienta ejecutar los prompts. Nunca bloquea la entrega |
| `{{generar_medios}}` | `sí` \| `no` *(por defecto `no`)* | **Opcional.** Si la skill debe **ejecutar** los prompts con OpenRouter |
| `{{clave_configurada}}` | `sí` \| `no` | Disponibilidad de la API Key de OpenRouter (en `~/.openrouter/api_key.txt`, ingresada en el chat como texto simple o mediante archivo `.txt`) |
| `{{medio_a_generar}}` | Imagen, Video, Ambas | Si es *ambas*: **primero las imágenes, después los videos** |
| `{{cantidad_a_generar}}` | Entero ≥ 1 | Mínimo 1, máximo los conceptos de la pasarela **que tengan ese medio** (`max_imagenes` / `max_videos`), no el total de conceptos |
| `{{modelo_openrouter}}` | Id de OpenRouter | Elegido por el usuario del **catálogo en vivo**. Nunca de memoria: los ids cambian |

---

## 💡 Niveles de Inventiva y Filosofía

- **Original ("Nada visto, pero con sentido"):** Cruces inesperados dentro de la memoria de marca (terruño, arte, ocasión, legado). Cambia el encuadre presentando el hecho con un ángulo nuevo.
- **Locura Genial ("Rompe el molde con dirección"):** Creatividad disruptiva, provocación artística y formatos atrevidos sin perder la elegancia y coherencia de marca.

> **Filtro de Locura Genial:** Obligatorio para **toda** idea. La idea debe demostrar creatividad trascendental, innovación disruptiva, valentía para desafiar, pasión profunda y autenticidad radical. Se descartan ideas sin propósito, imitativas o pretenciosas.

---

## 🔄 Flujo de Trabajo del Agente

```mermaid
flowchart TD
    A[Inicio / Petición del Usuario] --> B[Confirmar Plataformas Destino]
    B --> C[Detectar Feriados y Fechas de Bebidas]
    C --> D[Preguntar Obligatoriamente al Usuario qué Fecha Elegir]
    D --> E[Confirmar Producto del Portafolio]
    E --> F{¿Hay Link OneDrive/SharePoint?}
    F -- Sí --> G1[Preguntar si Leer Nombres de Campañas Pasadas]
    G1 --> G2[Extraer Metadatos vía Sub-Skill]
    G2 --> G3[Preguntar Obligatoriamente si Desea Adjuntar Imágenes de Muestra en Chat]
    G3 --> H[Definir Medio: Imagen / Video / Ambos]
    F -- No --> H
    H --> I[Ideación según Nivel de Inventiva]
    I --> J[Redactar Copys Nativos + Keywords SEO/GEO]
    J --> K[Generar Prompts Ultra Detallados para IA]
    K --> L[Verificación de Guardrails y QA Checklist]
    L --> M[Entrega con Plantilla + Pasarela Web HTML]
    M --> N{Extras opcionales — la entrega ya está completa}
    N -- Top de modelos --> O[Leaderboard en vivo vía API Design Arena]
    N -- Generar con OpenRouter --> P[check-key: ¿clave configurada?]
    N -- Ninguno --> Z[Fin]
    P -- No configurada --> P2[Indicar los 3 pasos: Bloc de notas y guardar]
    P2 --> P
    P -- Sin cuenta OpenRouter --> O
    P -- Configurada --> Q[Leer prompts de la pasarela: extract-prompts]
    Q --> R[Preguntar medio, cantidad y modelo del catálogo en vivo]
    R --> S[dry-run: mostrar COSTO ESTIMADO antes de gastar]
    S --> T[Generar: imágenes primero, luego videos]
    T --> U[Revisar guardrails y entregar pieza + copy + prompt/especificaciones]
```

---

## 🛡️ Memoria de Marca y Guardrails Innegociables

1. **Leyenda Obligatoria:** Toda pieza debe incluir `+18` y `Evita el exceso` (junto con el hashtag `#EspírituDeOrigen`).
2. **Exclusión de Menores:** Segmentación estricta +18 / +21 en pautas según la red.
3. **Cero Tolerancia a Excesos:** Nunca promover intoxicación, conducción bajo los efectos del alcohol ni consumo desmedido.
4. **Hechos de Marca Inviolables:**
   - Origen: El Arenal, Jalisco (Hacienda La Providencia, siglo XVIII).
   - Terruño: Paisaje Agavero UNESCO, agua del Bosque de la Primavera, suelo volcánico.
   - Categoría: Pionero en "Tequila de Terruño" (Single-Estate, 100% Agave Tequilana Weber Azul).
   - Tagline: *"Espíritu de Origen. Espíritu Excepcional. El primer Tequila de Terruño."*
5. **Coherencia Terminológica:** Usar siempre los nombres y términos oficiales establecidos en `references/seo-geo-glossary.md`.

---

## 👥 Glosario SEO / GEO y Personas

- **Alejandro (UHNWI, 45–60 años):** Mentor, coleccionista de arte, alta relojería y gastronomía de autor. Conexión por legado, exclusividad y curaduría.
- **Ana (HNWI, 40–50 años):** Disruptiva, emprendedora y coleccionista de diseño/arte contemporáneo. Conexión por originalidad y piezas limitadas.
- **Leonardo (Mass Affluent, 35–45 años):** Visionario, directivo/empresario, busca autenticidad y sofisticación para compartir quién es.
- **Efecto Halo:** Difusión aspiracional para el público general amante del tequila premium.

---

## 🌐 10. Pasarela Web Interactiva (Showcase / Runway)

La carpeta `showcase/` contiene una aplicación web interactiva diseñada para presentar las campañas publicitarias generadas de forma visual y ejecutiva:

- **Estructura tipo Pasarela:** Muestra cada concepto con su **Prompt generativo** (arriba, con parámetros de render y botón de copiado rápido) y su **Copy nativo** correspondiente (abajo, con hashtags y guardrails legales).
- **Leaderboard de Modelos IA:** Integra un ranking actualizado de herramientas de generación de imágenes basado en [Design Arena | Leaderboards](https://www.designarena.ai/leaderboard/image) (*FLUX.1 [pro], Midjourney v6.1, Google Imagen 3, Ideogram 2.0, Recraft v3, SD 3.5 Large*), evaluando su rendimiento específico para botellas de cristal, paisajes agaveros y tipografía.
- **Guía Técnica de Configuración:** Aspect ratios por plataforma, negative prompts obligatorios y consejos de iluminación claroscuro.
- **Tokens de Diseño:** Implementada con la identidad visual institucional de `designs/Design.md` (banda `--brand-maroon` `#6E1E28`, modo dark luxury y el logo oficial `imagenes/Loco_Tequila_Logo_white.png`).

Para visualizarla, abre directamente `showcase/index.html` en tu navegador web.

---

## 🎨 11. Generación de Medios con OpenRouter (extra opcional)

Una vez entregada la pasarela, la skill puede **ejecutar** los prompts que acaba de escribir contra los modelos de imagen y video de [OpenRouter](https://openrouter.ai), y devolver cada pieza junto con su copy y sus especificaciones. Es un **extra posterior a la entrega**: se ofrece, no se impone, y el consumo se cobra a la cuenta del usuario.

Detalle completo en [`sub-skill/generar-medios-openrouter/README.md`](sub-skill/generar-medios-openrouter/README.md).

```powershell
conda activate skills_env

# 1. Catálogo en vivo (no requiere API Key)
python sub-skill/generar-medios-openrouter/generar_medios.py --action list-models --type image

# 2. Leer los prompts de la pasarela ya generada (no requiere API Key)
python sub-skill/generar-medios-openrouter/generar_medios.py --action extract-prompts `
  --from-showcase showcase/campaign-2026-09-16-independencia-locura.html

# 3. Comprobar la configuración de la clave (sin exponerla)
python sub-skill/generar-medios-openrouter/generar_medios.py --action check-key

# 4. Ensayo SIN costo: prompts, aspecto, duración y costo estimado
python sub-skill/generar-medios-openrouter/generar_medios.py `
  --from-showcase showcase/campaign-2026-09-16-independencia-locura.html `
  --type image --model google/gemini-3-pro-image --first 3 --dry-run

# 5. Generar de verdad (quitar --dry-run)
```

**Puntos que conviene tener presentes:**

- **Manejo de la clave:** El script la lee de `~/.openrouter/api_key.txt`, de la variable de entorno o del parámetro `--api-key`. Si el usuario la ingresa en el chat, el agente la acepta y la configura de forma transparente. `.gitignore` excluye además `outputs/`, `*.key` y `openrouter*.txt`.
- **`--dry-run` es obligatorio antes de gastar:** resuelve todo y estima el costo sin llamar a la API.
- **Los prompts no se reescriben:** se leen del HTML de campaña, así que se ejecuta exactamente lo que se entregó.
- **Los flags de Midjourney (`--ar`, `--no`) se convierten en parámetros** y se quitan del texto: los modelos de OpenRouter los leerían como texto y podrían renderizarlos dentro de la imagen.
- **Las duraciones de video son conjuntos discretos, no rangos.** Veo 3.1 acepta solo 4/6/8 s; Sora 2 Pro 4/8/12/16/20 s. El script encaja duración y aspecto a lo que el modelo admite y **declara el ajuste**.
- **Un prompt de video de 24 s no se genera completo:** se obtiene un fragmento. El script lo dice en lugar de entregar 8 segundos como si fueran el spot.
- **El precio de video es por segundo** (de USD ~0.11/s en Kling v3.0 Pro a USD 0.50/s en Sora 2 Pro a 1080p), de ahí el tope de costo de 10 s ajustable con `--max-duration`.
